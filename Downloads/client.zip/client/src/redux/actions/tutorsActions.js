import Axios from 'axios';
import dispatch from 'react-redux';
import config from '../../Api/config';
import { TUTORSDATA } from '../actions/actionTypes';

const tutorData_url = config.baseUrl + "v1/client/tutor/";

const token = "ea90884565501e7b1854a165a0c0e828f0875c93"
let headers = {
    headers: {
        "Authorization": `Token ${token}`
    }
}

export const setTutorData = () => {
    Axios.get(tutorData_url, headers)
        .then(response => {
            console.log(response);
            dispatch({ type: TUTORSDATA, payload: response });
        }).catch(error => {
            console.log(error);
        })
}



