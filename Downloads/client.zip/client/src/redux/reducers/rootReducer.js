import { combineReducers } from 'redux';
import createAppReducer from '../reducers/clientReducer/clientReducer';

const RootReducer = combineReducers({
    createAppReducer
});
export default RootReducer;
