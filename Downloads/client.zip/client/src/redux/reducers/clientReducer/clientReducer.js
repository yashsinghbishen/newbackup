// // import { combineReducers } from 'redux';
// import { TUTORSDATA } from '../../actions/actionTypes'
// const iState = {
//     createTutorsData: {},
// };
// export const createAppReducer = (state = iState, action) => {
//     switch (action.type) {
//         case TUTORSDATA:
//             return {
//                 ...state,
//                 createTutorsData: action.payload,
//             };
//         default:
//             return state;
//     }
// };