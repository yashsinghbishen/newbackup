import React from 'react'

function Colors() {
  return (
    <div>

    </div>
  )
}

export default Colors
