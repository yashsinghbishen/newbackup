import React from 'react'

function Typography() {
  return (
    <div>

    </div>
  )
}

export default Typography
