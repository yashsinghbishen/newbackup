import React, { useState } from "react";
import CustomToolbar from "./CustomToolbar";
import events from "./events";
import {
  CDropdown,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
} from "@coreui/react";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import "react-big-calendar/lib/css/react-big-calendar.css";
import Modal from "../base/modal/Modal";
import SelectedModal from "../base/modal/SelectedModal";

moment.locale("en-GB");
const localizer = momentLocalizer(moment);

const Scheduler = (props) => {
  const [view, setView] = useState("week");
  const [modalShow, setModalShow] = useState(false);
  const [selectedModalShow, setSelectedModalShow] = useState(false);
  const [data, setData] = useState("");

  const renderDroupDown = () => {
    return (
      <CDropdown className="mt-2 week-dropdown">
        <CDropdownToggle className="week-btn">{view}</CDropdownToggle>
        <CDropdownMenu>
          <CDropdownItem onClick={() => setView("month")}>Month</CDropdownItem>
          <CDropdownItem onClick={() => setView("week")}>Week</CDropdownItem>
          <CDropdownItem onClick={() => setView("day")}>Day</CDropdownItem>
          <CDropdownItem onClick={() => setView("agenda")}>
            Agenda
          </CDropdownItem>
        </CDropdownMenu>
      </CDropdown>
    );
  };

  const onSelect = (e) => {
    setModalShow(true);
  };
  const onSelectedSlot = (e) => {
    setSelectedModalShow(true);
    setData(e);
  };

  const closeModal = () => {
    setModalShow(false);
  };

  const closeSelectedModal = () => {
    setSelectedModalShow(false);
  };

  const renderEventModal = () => {
    return <Modal open={modalShow} close={closeModal} />;
  };

  const renderSelectedEventModal = () => {
    return (
      <SelectedModal
        open={selectedModalShow}
        modalData={data}
        close={closeSelectedModal}
      />
    );
  };

  const reactBigCalender = () => {
    return (
      <Calendar
        selectable
        localizer={localizer}
        events={events}
        view={view}
        defaultView={view}
        views={["week", "month", "day", "agenda"]}
        startAccessor="start"
        endAccessor="end"
        components={{
          toolbar: CustomToolbar,
        }}
        style={{ height: 600 }}
        onSelectSlot={(e) => onSelect(e)}
        onSelectEvent={(e) => onSelectedSlot(e)}
        showMultiDayTimes
        eventPropGetter={
          () => {
            let newStyle = {
              backgroundColor: "rgb(240,240,240)",
              color: 'black',
              borderRadius: "0px",
              border: "none"
            };
            return {
              className: "",
              style: newStyle
            };
          }
        }
      />
    );
  };

  return (
    <div>
      <div className="position-relative">{renderDroupDown()}</div>
      {reactBigCalender()}
      {renderEventModal()}
      {renderSelectedEventModal()}
    </div>
  );
};

export default Scheduler;
