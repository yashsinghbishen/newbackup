import React from "react";
import moment from "moment";

const CustomToolbar = (toolbar) => {
  const goToBack = () => {
    toolbar.date.setMonth(toolbar.date.getMonth() - 1);
    toolbar.onNavigate("prev");
  };

  const goToNext = () => {
    toolbar.date.setMonth(toolbar.date.getMonth() + 1);
    toolbar.onNavigate("next");
  };

  const goToCurrent = () => {
    const now = new Date();
    toolbar.date.setMonth(now.getMonth());
    toolbar.date.setYear(now.getFullYear());
    toolbar.onNavigate("current");
  };

  const label = () => {
    const date = moment(toolbar.date);
    return (
      <span>
        <b>{date.format("MMMM YYYY")}</b>
        <span> {date.format("YYYY")}</span>
      </span>
    );
  };

  return (
    <div className="bg-calender">
      <div className="today-div">
        <button className="mr-2 btn today-btn" onClick={goToCurrent}>
          Today
        </button>
        <button className="mr-2 btn goto_back" onClick={goToBack}>
          &#8249;
        </button>
        <button className="mr-2 btn goto_next" onClick={goToNext}>
          &#8250;
        </button>
      </div>
      <label className="month-name">{label()}</label>
    </div>
  );
};

export default CustomToolbar;
