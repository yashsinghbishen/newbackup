import React from "react";
import {
  CCol,
  CNav,
  CNavItem,
  CNavLink,
  CRow,
  CTabContent,
  CTabPane,
  CCard,
  CTabs,
} from "@coreui/react";

const TabsPayment = () => {
  return (
    <CRow>
      <CCol xs="12" md="12" className="mb-4 header-navbartab">
        <CCard>
          <CTabs>
            <CNav variant="tabs">
              <CNavItem>
                <CNavLink>Tutor</CNavLink>
              </CNavItem>
              <CNavItem>
                <CNavLink>Students</CNavLink>
              </CNavItem>
            </CNav>
            <CTabContent>
              <CTabPane className="table-responsive usertable_container">
                <table className="table tabs-data">
                  <thead>
                    <tr>
                      <th className="userid" scope="col">
                        ID
                      </th>
                      <th className="userid" scope="col">
                        APPOINTMENT ID
                      </th>
                      <th scope="col">APPOINTMENT TUTOR</th>
                      <th scope="col">STATUS</th>
                      <th scope="col">PAYMENT INFO</th>
                      <th scope="col">CREATE AT</th>
                      <th scope="col">UPDATE AT</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th className="userid" scope="row">
                        1
                      </th>
                      <td>Mark</td>
                      <td>Otto</td>
                      <td>@mdo</td>
                      <td>@mdo</td>
                      <td>@mdo</td>
                      <td>@mdo</td>
                    </tr>
                  </tbody>
                </table>
              </CTabPane>
              <CTabPane className="table-responsive usertable_container">
                <table className="table tabs-data">
                  <thead>
                    <tr>
                      <th className="userid" scope="col">
                        ID
                      </th>
                      <th scope="col">APPOINTMENT ID</th>
                      <th scope="col">APPOINTMENT TUTOR</th>
                      <th scope="col">STATUS</th>
                      <th scope="col">PAYMENT INFO</th>
                      <th scope="col">CREATE AT</th>
                      <th scope="col">UPDATE AT</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th class="userid" scope="row">
                        1
                      </th>
                      <td>Mark</td>
                      <td>Otto</td>
                      <td>@mdo</td>
                      <td>@mdo</td>
                      <td>@mdo</td>
                      <td>@mdo</td>
                    </tr>
                  </tbody>
                </table>
              </CTabPane>
            </CTabContent>
          </CTabs>
        </CCard>
      </CCol>
    </CRow>
  );
};

export default TabsPayment;
