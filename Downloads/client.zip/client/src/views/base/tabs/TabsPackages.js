import React from "react";
import {
  CCol,
  CNav,
  CNavItem,
  CNavLink,
  CRow,
  CCard,
  CTabs,
  CTabContent,
  CTabPane,
} from "@coreui/react";

function TabsPackages() {
  return (
    <CRow className="package-section">
      <CCol xs="12" md="12" className="mb-4 header-navbartab">
        <CCard>
          <CTabs>
            <CNav variant="tabs">
              <CNavItem>
                <CNavLink>Tutor</CNavLink>
              </CNavItem>
              <CNavItem>
                <CNavLink>Students</CNavLink>
              </CNavItem>
              <CTabContent>
                <CTabPane className="table-responsive">
                  <div>
                    <div className="package_container">
                      <p className="packagetext">Package</p>
                      <div className="package_contenttext">
                        <p className="access_text">
                          Access a complecte payments platform with simple,
                          pay-as-you-go pricing
                        </p>
                        <h3>
                          50.000 <span>AUD</span>
                        </h3>
                        <p className="package_payment">Package Type:Payment</p>
                      </div>
                      <p className="gettext">GET STARTED IN MINUTES</p>
                    </div>
                  </div>
                </CTabPane>
                <CTabPane className="table-responsive">
                  <div>
                    <div className="package_container">
                      <p className="packagetext">Package</p>
                      <div className="package_contenttext">
                        <p className="access_text">
                          Access a complecte payments platform with simple,
                          pay-as-you-go pricing
                        </p>
                        <h3>
                          50.000 <span>AUD</span>
                        </h3>
                        <p className="package_payment">Package Type:Payment</p>
                      </div>
                      <p className="gettext">GET STARTED IN MINUTES</p>
                    </div>
                  </div>
                </CTabPane>
              </CTabContent>
            </CNav>
          </CTabs>
        </CCard>
      </CCol>
    </CRow>
  );
}

export default TabsPackages;
