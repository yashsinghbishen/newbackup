import React from "react";
import moment from "moment";
import { FaEdit } from 'react-icons/fa';
import { AiFillClockCircle, AiFillCloseCircle } from "react-icons/ai";
import { CModal, CModalHeader, CModalBody } from "@coreui/react";

const SelectedModal = ({ open, close, modalData }) => {
  return (
    <div className="">
      <CModal show={open} centered={true} onClose={() => close()}>
        <CModalHeader className="selected-closebtn">
          <div className='selectedModal '> <div>  {modalData.title}</div>
            <div>
              <FaEdit className='FaEdit' />
              <AiFillCloseCircle onClick={() => close()} />
            </div>
          </div>
        </CModalHeader>
        <CModalBody className="selected-modal" id="selected_pop">
          <div>
            <h3 className="testing-purpose">Testing Purpose</h3>
            <p className="date-all">
              {moment(modalData.start).format("ddd, MMMM D YYYY")}
            </p>
          </div>

          <p className="color_clockdiv line_height">
            <span className="color-clock">
              <AiFillClockCircle />
            </span>
            {moment(modalData.start).format("HH:mm a")}-
            {moment(modalData.end).format("HH:mm a")}
          </p>

          <p className=" line_height">
            <span className="round-div color-task"></span>Task
          </p>
          <p className=" line_height">
            <span className="round-div color-complete"></span>Completed
          </p>
          <p className=" line_height">
            <span className="round-div color-yuna"></span>Yuna Kubota
          </p>
        </CModalBody>
      </CModal>
    </div>
  );
};

export default SelectedModal;
