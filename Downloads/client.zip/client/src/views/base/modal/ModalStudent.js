import React from "react";
import { FaUserAlt, FaCircleNotch } from "react-icons/fa";
import { GiBookPile } from "react-icons/gi";
import { HiCurrencyDollar } from "react-icons/hi";
import { BiDetail } from "react-icons/bi";
import { BsPersonLinesFill } from "react-icons/bs";
import { AiFillClockCircle } from "react-icons/ai";
import { IoLocation } from "react-icons/io5";
import Icon from "../../../assets/icons/scheduler-hover.png";

import { CModal, CModalHeader, CModalBody } from "@coreui/react";

const ModalStudent = ({ open, close }) => {
  return (
    <div className="tutor-modal student-modal">
      <CModal show={open} centered={true} onClose={() => close()}>
        <CModalHeader closeButton>
          <h2 className="modal-heading">Add Task </h2>
        </CModalHeader>
        <CModalBody>
          <div className="row">
            <div className="col-md-4">
              <div className="row">
                <div className="col-md-12">
                  <div className="first_col">
                    <div className="row">
                      <div className="col-md-1 col-1">
                        <FaUserAlt className="study_icon" />
                      </div>
                      <div className="col-md-11 col-10">
                        <div className="display_div">
                          <p>client</p>
                          <p>joshua</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <div className="first_col">
                    <div className="row">
                      <div className="col-md-1 col-1">
                        <GiBookPile className="study_icon" />
                      </div>
                      <div className="col-md-11 col-10">
                        <div className="display_div">
                          <p>subjects</p>
                          <p>maths</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <div className="first_col">
                    <div className="row">
                      <div className="col-md-1 col-1">
                        <HiCurrencyDollar className="study_icon" />
                      </div>
                      <div className="col-md-11 col-10">
                        <div className="display_div">
                          <p>travel commision</p>
                          <p>30,000</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <div className="first_col">
                    <div className="row">
                      <div className="col-md-1 col-1">
                        <BiDetail className="study_icon" />
                      </div>
                      <div className="col-md-11 col-10">
                        <div className="display_div">
                          <p>desciption</p>
                          <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit. Quisque nisl eros, pulvinar facilisis justo
                            mollis, auctor consequat urna.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="row">
                <div className="col-md-12">
                  <div className="first_col">
                    <div className="row">
                      <div className="col-md-1 col-1">
                        <HiCurrencyDollar className="study_icon" />
                      </div>
                      <div className="col-md-10 col-10">
                        <div className="display_div">
                          <p>in person rate</p>
                          <p>30,000</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <div className="first_col">
                    <div className="row">
                      <div className="col-md-1 col-1">
                        <HiCurrencyDollar className="study_icon" />
                      </div>
                      <div className="col-md-10 col-11">
                        <div className="display_div">
                          <p>video call rate</p>
                          <p>30,000</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <div className="first_col">
                    <div className="row">
                      <div className="col-md-1 col-1">
                        <BsPersonLinesFill className="study_icon" />
                      </div>
                      <div className="col-md-10 col-11">
                        <div className="display_div">
                          <p>personality</p>
                          <p>cool</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <div className="first_col">
                    <div className="row">
                      <div className="col-md-1 col-1">
                        <FaCircleNotch className="study_icon" />
                      </div>
                      <div className="col-md-10 col-11">
                        <div className="display_div">
                          <p>status</p>
                          <p>availabile for application</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <div className="first_col">
                    <div className="row">
                      <div className="col-md-1 col-1">
                        <AiFillClockCircle className="study_icon" />
                      </div>
                      <div className="col-md-10 col-11">
                        <div className="display_div">
                          <p>availability</p>
                          <p>monday</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="row">
                <div className="col-md-12">
                  <div className="first_col">
                    <div className="row">
                      <div className="col-md-1 col-1">
                        <IoLocation className="study_icon" />
                      </div>
                      <div className="col-md-10 col-11">
                        <div className="display_div">
                          <p>location</p>
                          <div className="btn-viewdiv">
                            <button className="btn btn-view">view</button>
                          </div>
                          <p>
                            Lorem Ipsum Dolor Sit Amet, Consectetur Adipiscing
                            Elit
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-md-12">
                  <div className="first_col">
                    <div className="row">
                      <div className="col-md-1 col-1">
                        <img src={Icon} alt="" />
                      </div>
                      <div className="col-md-10 col-11">
                        <div className="display_div">
                          <p>appointment</p>
                          <div className="btn-viewdiv">
                            <button className="btn btn-view">view</button>
                          </div>
                          <p>30,000</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CModalBody>
      </CModal>
    </div>
  );
};

export default ModalStudent;
