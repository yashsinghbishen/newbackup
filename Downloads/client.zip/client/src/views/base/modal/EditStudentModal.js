import React, { useState } from "react";
import Axios from "axios";
import DatePicker from "react-datepicker";
import {
    CModal,
    CModalHeader,
    CModalBody,
    CButton,
    CForm,
} from "@coreui/react";
import config from "../../../Api/config";
import "react-datepicker/dist/react-datepicker.css";

const EditStudentModal = ({ open, close }) => {
    // const [startDate, setStartDate] = useState(new Date());
    // const [firstName, setFirstName] = useState("");
    // const [lastName, setLastName] = useState("");
    // const [email, setEmail] = useState("");
    // const [subjects, setSubjects] = useState([]);
    // const [school, setSchool] = useState("");
    // const [grade, setGrade] = useState("");
    // const [info, setInfo] = useState("");
    // const [phoneNumber, setPhoneNumber] = useState("");

    const edit_TutorData_url = config.baseUrl + "v1/client/student/4/";


    // const studentData = async () => {

    //     // const token = "ea90884565501e7b1854a165a0c0e828f0875c93";
    //     // let headers = {
    //     //     headers: {
    //     //         Authorization: `Token ${token}`,
    //     //     },
    //     // };
    //     await Axios.patch(edit_TutorData_url, headers)
    //         .then((response) => {
    //             // let studentData = response.data;
    //             // setData(Object.values(studentData));
    //             console.log("+++", response);
    //             // console.log(studentData)
    //         })
    //         .catch((error) => {
    //             console.log(error);
    //         });
    // };

    // const handleSubmit = (event) => {
    //     const formData = new FormData();
    //     formData.append("firstName", firstName);
    //     formData.append("lastName", lastName);
    //     formData.append("email", email);
    //     formData.append("startDate", startDate);
    //     formData.append("subjects", subjects);
    //     formData.append("school", school);
    //     formData.append("grade", grade);
    //     formData.append("info", info);
    //     formData.append("phoneNumber", phoneNumber)


    //     Axios.patch(edit_TutorData_url, formData, { headers: headers })
    //         .then((result) => {
    //             console.log("++++++", result);
    //         })
    //         .catch((error) => {
    //             console.log("+++++", error)
    //         });
    //     event.preventDefault();
    // }




    return (
        <div className="schedular-modal">
            <CModal show={open} centered={true} onClose={() => close()}>
                {/* <CModalHeader closeButton>
                    <h2 className="modal-heading">Edit Data</h2>

                    <CButton block color="primary" id="modal-savebtn" onClick={handleSubmit}>
                        Submit
                    </CButton>
                </CModalHeader>
                <CModalBody>
                    <CForm className="user_modalform user_modalform1">
                        <div className="input-wrapper">
                            <label for="user">First Name*</label>
                            <input type="text" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
                        </div>
                        <div className="input-wrapper">
                            <label for="user">Last Name*</label>
                            <input type="text" value={lastName} onChange={(e) => setLastName(e.target.value)} />
                        </div>
                        <div className="input-wrapper">
                            <label for="user">Email*</label>
                            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                        </div>
                        <div className="input-wrapper">
                            <label for="user">Date Of Birth*</label>
                            <DatePicker value={startDate} selected={startDate} onChange={date => setStartDate(date)} />
                        </div>
                        <div className="input-wrapper">
                            <label for="user">Subjects*</label>
                            <input type="text" value={subjects} onChange={(e) => setSubjects(e.target.value)} />
                        </div>
                        <div className="input-wrapper">
                            <label for="user">School*</label>
                            <input type="text" value={school} onChange={(e) => setSchool(e.target.value)} />
                        </div>
                        <div className="input-wrapper">
                            <label for="user">Grade*</label>
                            <input type="text" value={grade} onChange={(e) => setGrade(e.target.value)} />
                        </div>
                        <div className="input-wrapper">
                            <label for="user">Info*</label>
                            <input type="text" value={info} onChange={(e) => setInfo(e.target.value)} />
                        </div>
                        <div className="input-wrapper">
                            <label for="user">Phone Number*</label>
                            <input type="text" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} />
                        </div>
                    </CForm>
               </CModalBody>*/}
            </CModal>
        </div>
    );
};

export default EditStudentModal;