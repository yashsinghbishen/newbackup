import React, { useState, useEffect } from "react";
import Axios from "axios";
import DatePicker from "react-datepicker";
import {
  CModal,
  CModalHeader,
  CModalBody,
  CButton,
  CForm,
} from "@coreui/react";
import config from "../../../Api/config";
import "react-datepicker/dist/react-datepicker.css";

const Modal = ({ open, close }) => {
  const [startDate, setStartDate] = useState(new Date());
  const [data, setData] = useState([]);
  const [optionDataForAppoinment, setOptionDataForAppoinment] = useState([]);
  const [topic, setTopic] = useState();

  const popup_options_url = config.baseUrl + "v1/client/appointment/";
  // const create_new_appoinment = config.baseUrl + "v1/client/appointment/";

  const popupOptions = async () => {

    const token = "ea90884565501e7b1854a165a0c0e828f0875c9";
    let headers = {
      headers: {
        Authorization: `Token ${token}`,
        lesson: 9
      },
    };
    await Axios.options(popup_options_url, headers)
      .then((response) => {
        const optionData = response.data.actions.POST.students.choices;
        const optionDataForAppoinmentType = response.data.actions.POST.appointment_type.choices;
        setData(Object.values(optionData));
        console.log("**********", response)
        setOptionDataForAppoinment(Object.values(optionDataForAppoinmentType))
      })
      .catch(({ ...error }) => {
        console.log(error);
      });
  };

  const createNewAppoinment = async () => {
    const token = "ea90884565501e7b1854a165a0c0e828f0875c93";
    let headers = {
      headers: {
        Authorization: `Token ${token}`,
        lesson: 9
      },
    };
    await Axios.post(popup_options_url, headers)
      .then((response) => {
        console.log(response)
      }).catch((error) => {
        console.log(error)
      })
  }


  useEffect(() => {
    // const subscription$ = tutorData();
    // return () => {
    //   if (subscription$) {
    //     subscription$.unsubscribe();
    //   }
    // };
    popupOptions()
  }, []);

  const renderDropDown = () => {
    return (
      data &&
      data.length > 0 &&
      data.map((post, i) => {
        const {
          user__first_name,
          user__last_name
        } = post;
        return (
          <option key={post.id}>{user__first_name} {user__last_name}</option>
        );
      })
    );
  }

  const renderDropDownForAppoinmentTypes = () => {
    return (
      optionDataForAppoinment && optionDataForAppoinment.length > 0 && optionDataForAppoinment.map((post, i) => {
        const {
          value
        } = post;
        return (
          <option key={post.id}>{value}</option>
        )
      })
    )
  }
  return (
    <div className="schedular-modal">
      <CModal show={open} centered={true} onClose={() => close()}>
        <CModalHeader closeButton>
          <h2 className="modal-heading">Add Appoinment</h2>

          <CButton block color="primary" id="modal-savebtn" onClick={createNewAppoinment}>
            Save
          </CButton>
        </CModalHeader>
        <CModalBody>
          <CForm className="user_modalform user_modalform1">
            <div className="input-wrapper">
              <label for="user">Topic*</label>
              <input type="text" value={topic} onChange={(e) => setTopic(e.target.value)} />
            </div>
            <div className="input-wrapper">
              <select name="cars" id="cars" className="custom-select">
                {renderDropDown()}
                <label for="user">Students*</label>
              </select>
            </div>
            <div className="input-wrapper">
              <input type="text" rows="6" required />
              <label for="user">Location*</label>
            </div>
            <div className="input-wrapper">
              <DatePicker value={startDate} selected={startDate} onChange={date => setStartDate(date)} />
              <label for="user">Start Time*</label>
            </div>
            <div className="input-wrapper">
              <DatePicker value={startDate} selected={startDate} onChange={date => setStartDate(date)} />
              <label for="user">End Time*</label>
            </div>
            <div className="input-wrapper">
              <select name="cars" id="cars" className="custom-select">
                {renderDropDownForAppoinmentTypes()}
              </select>
              <label for="user">Appoinment Type*</label>
            </div>
            <div className="input-wrapper">
              <textarea placeholder="Additional Info" />
            </div>
          </CForm>
        </CModalBody>
      </CModal>
    </div>
  );
};

export default Modal;
