import React from 'react'

function Widgets() {
  return (
    <div>

    </div>
  )
}

export default Widgets
