import React from 'react'

function WidgetsBrand() {
  return (
    <div>

    </div>
  )
}

export default WidgetsBrand
