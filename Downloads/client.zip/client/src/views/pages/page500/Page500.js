import React from 'react'

function Page500() {
  return (
    <div>

    </div>
  )
}

export default Page500
