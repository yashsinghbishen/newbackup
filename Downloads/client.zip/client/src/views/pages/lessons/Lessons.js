import React, { useState, useEffect } from "react";
import Axios from "axios";
import Loader from 'react-loader';
import ModalLesson from "../../base/modal/ModalLesson";
import config from "../../../Api/config";

function Lessons() {
  const [modalShow, setModalShow] = useState(false);
  const [data, setData] = useState([]);

  const lessons_url = config.baseUrl + "v1/client/lesson/";

  const token = "ea90884565501e7b1854a165a0c0e828f0875c93";
  let headers = {
    headers: {
      Authorization: `Token ${token}`,
    },
  };

  const lessonsData = async () => {
    await Axios.get(lessons_url, headers)
      .then((response) => {
        let lessonsData = response.data;
        setData(Object.values(lessonsData));
        console.log("Lessons Data", lessonsData)
      })
      .catch((error) => {
        console.log(error);
      });
  };
  useEffect(() => {
    // const subscription$ = tutorData();
    // return () => {
    //   if (subscription$) {
    //     subscription$.unsubscribe();
    //   }
    // };
    lessonsData()
  }, []);

  const onSelect = (e) => {
    setModalShow(true);
  };
  const closeModal = () => {
    setModalShow(false);
  };

  const renderModal = () => {
    return <ModalLesson open={modalShow} close={closeModal} />;
  };

  const renderTableData = () => {
    if (!data) {
      return <Loader />;
    }
    return (
      data &&
      data.length > 0 &&
      data.map((post, i) => {
        const {
          id,
          subjects,
          lesson_type,
          status,
          extra_student_discount
        } = post;
        return (
          <tr key={post.id + i}>
            <td>{id}</td>
            <td></td>
            <td></td>
            <td></td>
            <td>{subjects[0]}</td>
            <td></td>
            <td></td>
            <td>{lesson_type}</td>
            <td>{status}</td>
            <td></td>
            <td>{extra_student_discount}</td>
            <td> </td>
          </tr>
        );
      })
    );
  };

  return (
    <>
      <div
        className="table-responsive lesson-page usertable_container"
        onClick={onSelect}
      >
        <table className="table table-striped table-inverse user_table">
          <thead className="listtable_data">
            <tr>
              <th className="userid">ID</th>
              <th>LAST APPOINMENT STUDENT</th>
              <th>LAST APPOINMENT NOTES</th>
              <th>LAST APPOINMENT NOTES</th>
              <th>SUBJECT</th>
              <th>FEEDBACK</th>
              <th>FIRST APPOINMENT ON</th>
              <th>LESSON TYPE</th>
              <th>STATUS</th>
              <th>TRAVEL COMMISSON</th>
              <th>EXTRA STUDENT DISCOUNT</th>
            </tr>
          </thead>
          <tbody>
            {/*<tr className="table_list">
              <td className="userid">1</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>@mdo</td>
            </tr>
            <tr className="table_list">
              <td className="userid">2</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>@mdo</td>
            </tr>
            <tr className="table_list">
              <td className="userid">3</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>@mdo</td>
  </tr> */}
            {renderTableData()}
          </tbody>
        </table>
      </div>
      {renderModal()}
    </>
  );
}

export default Lessons;
