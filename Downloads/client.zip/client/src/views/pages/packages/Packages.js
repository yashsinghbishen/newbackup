import React from "react";
import TabsPackages from "../../base/tabs/TabsPackages";

function Packages() {
  return <TabsPackages />;
}

export default Packages;
