import React, { useState, useEffect } from "react";
import Axios from "axios";
import Loader from 'react-loader';
import ModalTutors from "../../base/modal/ModalTutors";
import config from "../../../Api/config";

function Tutors() {
  const [modalShow, setModalShow] = useState(false);
  const [data, setData] = useState([]);

  const tutorData_url = config.baseUrl + "v1/client/tutor/";

  const token = "ea90884565501e7b1854a165a0c0e828f0875c93";
  let headers = {
    headers: {
      Authorization: `Token ${token}`,
    },
  };
  const tutorData = async () => {
    await Axios.get(tutorData_url, headers)
      .then((response) => {
        let tutorData = response.data;
        setData(Object.values(tutorData));
        console.log(tutorData)
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    // const subscription$ = tutorData();
    // return () => {
    //   if (subscription$) {
    //     subscription$.unsubscribe();
    //   }
    // };
    tutorData()
  }, []);

  const onSelect = (e) => {
    setModalShow(true);
  };
  const closeModal = () => {
    setModalShow(false);
  };

  const renderModal = () => {
    return <ModalTutors open={modalShow} close={closeModal} />;
  };

  const renderTableData = () => {
    if (!data) {
      return <Loader />;
    }
    return (
      data &&
      data.length > 0 &&
      data.map((post, i) => {
        const {
          id,
          user,
          location,
          subjects,
          bio,
          experience,
          phone_number,
        } = post;
        return (
          <tr key={post.id + i}>
            <td>{id}</td>
            <td>{user.first_name}</td>
            <td>{user.last_name}</td>
            <td>{user.email}</td>
            <td>{JSON.stringify(location)}</td>
            <td>{subjects[0]}</td>
            <td>{bio}</td>
            <td>{experience}</td>
            <td>{phone_number}</td>
          </tr>
        );
      })
    );
  };

  return (
    <>
      <div className="table-responsive usertable_container" onClick={onSelect}>
        <table className="table table-striped table-inverse user_table">
          <thead className="listtable_data">
            <tr>
              <th className="userid">ID</th>
              <th>User First Name</th>
              <th>User Last Name</th>
              <th>User Email Address</th>
              <th>Location</th>
              <th>Subject</th>
              <th>Bio</th>
              <th>Experiencs</th>
              <th>Phone Number</th>
            </tr>
          </thead>
          <tbody>
            {renderTableData()}
          </tbody>
        </table>
      </div>
      {renderModal()}
    </>
  );
}

export default Tutors;
