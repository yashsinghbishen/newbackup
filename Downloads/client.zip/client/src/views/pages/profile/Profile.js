import React from "react";
import ProfileLogo from "../../../assets/icons/profile-two.png";

function Profile() {
  return (
    <div className="container form_container">
      <img src={ProfileLogo} alt="user" className="user_img" />
      <form className="user_form">
        <div className="row">
          <div className="col-md-6 input-wrapper">
            <input type="text" id="user" required />
            <label for="user">First name</label>
          </div>

          <div className="col-md-6 input-wrapper">
            <input type="password" required />
            <label for="user">Last name</label>
          </div>

          <div className="col-md-6 input-wrapper">
            <input type="password" required />
            <label for="user">Email address</label>
          </div>
        </div>
        <button className="subbtn">Submit</button>
      </form>
    </div>
  );
}

export default Profile;
