import React from "react";
import { BiSmile } from "react-icons/bi";
import { ImAttachment } from "react-icons/im";
import { FiSend } from "react-icons/fi";
import { IoEllipsisVerticalSharp } from "react-icons/io5";

function Chat() {
  return (
    <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 conversation appraisalDetail nopadd">
      <div className="chat_content_container">
        <div className="chatting_text available-items userchatpadd">
          <div className="user_first">
            <div className="avatar-icon">
              <p className="profileImage">A</p>
            </div>
            <div className="chat_message">
              <h2 className="user_heading">Anna Bridges</h2>
              <p className="firstuser_message">
                Lorem ipsum, or lipsum as it is sometimes known, is dummy text
                used in laying out print, graphic or web designs. The passage is
                attributed to an unknown typesetter
            </p>
              <p className="user_time">8 Minutes ago</p>
            </div>
            <div className="ellipse_chat">
              <IoEllipsisVerticalSharp />
            </div>
          </div>
          <div className="user_second">
            <div className="avatar-icon">
              <p className="profileImage seconduserprofile">A</p>
            </div>
            <div className="chat_message">
              <h2 className="user_heading">Anna Bridges</h2>
              <p className="firstuser_message">Hello, i am good,thanks</p>
              <p className="user_time">8 Minutes ago</p>
            </div>
            <div className="ellipse_chat">
              <IoEllipsisVerticalSharp />
            </div>
          </div>
          <div className="right_sectionchat">
            <div className="ellipse_chat1">
              <IoEllipsisVerticalSharp />
            </div>
            <div className="user_second">
              <div className="chat_message chat_message1">
                <h2 className="user_heading">Anna Bridges</h2>
                <p className="firstuser_message">Hello, i am good,thanks</p>
                <p className="user_time">8 Minutes ago</p>
              </div>
              <div className="avatar-icon">
                <p className="profileImage profileImage1 seconduserprofile">Y</p>
              </div>
            </div>
          </div>
          <div className="right_sectionchat">
            <div className=" ellipse_chat1">
              <IoEllipsisVerticalSharp />
            </div>
            <div className="user_second">
              <div className="chat_message chat_message1">
                <h2 className="user_heading">Anna Bridges</h2>
                <p className="firstuser_message">Hello, i am good,thanks</p>
                <p className="user_time">8 Minutes ago</p>
              </div>
              <div className="avatar-icon">
                <p className="profileImage profileImage1 seconduserprofile">Y</p>
              </div>
            </div>
          </div>
        </div>

        <div className="chat_send">
          <input type="text" placeholder="Type your message" />
          <div className="chatmsg_icons">
            <span className="chat_hover">
              <BiSmile className="input_cht" />
            </span>
            <span className="chat_hover">
              <ImAttachment className="input_cht" />
            </span>
            <span className="chat_hover">
              <FiSend className="input_cht" />
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Chat;
