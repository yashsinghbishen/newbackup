import React, { useState, useEffect } from "react";
import Axios from "axios";
import Loader from 'react-loader';
import { IoEllipsisVerticalOutline } from "react-icons/io5";
import { BsTrash } from "react-icons/bs";
import { MdEdit } from "react-icons/md";
import { IoEllipsisVerticalSharp } from "react-icons/io5";
import ModalStudent from "../../base/modal/ModalStudent";
import EditStudentModal from "../../base/modal/EditStudentModal";
import config from "../../../Api/config";

function Students() {
  const [modalShow, setModalShow] = useState(false);
  const [editModalShow, setEditModalShow] = useState(false)
  const [data, setData] = useState([]);

  const student_url = config.baseUrl + "v1/client/student/";

  const token = "ea90884565501e7b1854a165a0c0e828f0875c93";
  let headers = {
    headers: {
      Authorization: `Token ${token}`,
    },
  };

  const studentData = async () => {
    await Axios.get(student_url, headers)
      .then((response) => {
        let studentData = response.data;
        setData(Object.values(studentData));
        console.log(studentData)
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    // const subscription$ = tutorData();
    // return () => {
    //   if (subscription$) {
    //     subscription$.unsubscribe();
    //   }
    // };
    studentData()
  }, []);
  const renderEventModal = () => {
    return <ModalStudent open={modalShow} close={closeModal} />
  };

  const renderEditModal = () => {
    return <EditStudentModal open={editModalShow} close={closeModalEdit} />
  };

  const onSelect = (e) => {
    setModalShow(true);
  };

  const onSelectEdit = (e) => {
    setEditModalShow(true);
  }

  const closeModal = () => {
    setModalShow(false);
  };

  const closeModalEdit = () => {
    setEditModalShow(false);
  }

  const renderTableData = () => {
    if (!data) {
      return <Loader />;
    }
    return (
      data &&
      data.length > 0 &&
      data.map((post, i) => {
        const {
          id,
          user,
          dob,
          subjects,
          bio,
          experience,
          phone_number,
        } = post;
        return (
          <tr key={post.id + i}>
            <td>{id}</td>
            <td>{user.first_name}</td>
            <td>{user.last_name}</td>
            <td>{user.email}</td>
            <td>{dob}</td>
            <td>{subjects[0]}</td>
            <td>{bio}</td>
            <td>{experience}</td>
            <td>{phone_number}</td>
            <td> <div className="table-actionbtnweb">
              <button className="delete_btn">Delete</button>
              <button className="edit_btn" onClick={onSelectEdit}>Edit</button>
              <button className="table_menu">
                <IoEllipsisVerticalOutline />
              </button>
            </div>
              <div className="table-actionbtn">
                <BsTrash className="delete_icon" />
                <MdEdit className="edit_icon" />
                <IoEllipsisVerticalSharp className="vertical_icon" />
              </div></td>
          </tr>
        );
      })
    );
  };

  return (
    <>
      <div className="table-responsive usertable_container" onClick={onSelect}>
        <table className="table table-striped table-inverse user_table">
          <thead className="listtable_data">
            <tr>
              <th className="userid">id</th>
              <th>User First Name</th>
              <th>User Last Name</th>
              <th>User Email Address</th>
              <th>Location</th>
              <th>Subject</th>
              <th>Bio</th>
              <th>Experiencs</th>
              <th>Phone Number</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {/*  <tr className="table_list">
              <td className="userid">1</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>
                <div className="table-actionbtnweb">
                  <button className="delete_btn">Delete</button>
                  <button className="edit_btn">Edit</button>
                  <button className="table_menu">
                    <IoEllipsisVerticalOutline />
                  </button>
                </div>
                <div className="table-actionbtn">
                  <BsTrash className="delete_icon" />
                  <MdEdit className="edit_icon" />
                  <IoEllipsisVerticalSharp className="vertical_icon" />
                </div>
              </td>
            </tr>
            <tr className="table_list">
              <td className="userid">2</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>
                <div className="table-actionbtnweb">
                  <button className="delete_btn">Delete</button>
                  <button className="edit_btn">Edit</button>
                  <button className="table_menu">
                    <IoEllipsisVerticalOutline />
                  </button>
                </div>
                <div className="table-actionbtn">
                  <BsTrash className="delete_icon" />
                  <MdEdit className="edit_icon" />
                  <IoEllipsisVerticalSharp className="vertical_icon" />
                </div>
              </td>
            </tr>
            <tr className="table_list">
              <td className="userid">3</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>@mdo</td>
              <td>
                <div className="table-actionbtnweb">
                  <button className="delete_btn">Delete</button>
                  <button className="edit_btn">Edit</button>
                  <button className="table_menu">
                    <IoEllipsisVerticalOutline />
                  </button>
                </div>
                <div className="table-actionbtn">
                  <BsTrash className="delete_icon" />
                  <MdEdit className="edit_icon" />
                  <IoEllipsisVerticalSharp className="vertical_icon" />
                </div>
              </td>
         </tr> */}
            {renderTableData()}
          </tbody>
        </table>
      </div>
      { renderEventModal()}
      {renderEditModal()}
    </>
  );
}

export default Students;
