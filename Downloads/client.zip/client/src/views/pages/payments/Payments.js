import React from "react";
// import TabsPayment from "../../base/tabs/TabsPayment";
function Payments() {
  return (
    <div>
      {/* <TabsPayment /> */}
    </div>
  );
}

export default Payments;
