import React from 'react'

function Page404() {
  return (
    <div>

    </div>
  )
}

export default Page404

