import React from "react";

const Toaster = React.lazy(() =>
  import("./views/notifications/toaster/Toaster")
);

const BrandButtons = React.lazy(() =>
  import("./views/buttons/brand-buttons/BrandButtons")
);
const ButtonDropdowns = React.lazy(() =>
  import("./views/buttons/button-dropdowns/ButtonDropdowns")
);
const ButtonGroups = React.lazy(() =>
  import("./views/buttons/button-groups/ButtonGroups")
);
const Charts = React.lazy(() => import("./views/charts/Charts"));
const Scheduler = React.lazy(() =>
  import("./views/scheduler/Scheduler")
);
const Tutors = React.lazy(() => import("./views/pages/tutors/Tutors"));
const Students = React.lazy(() => import("./views/pages/students/Students"));
const Lessons = React.lazy(() => import("./views/pages/lessons/Lessons"));
const Payments = React.lazy(() => import("./views/pages/payments/Payments"));
const Packages = React.lazy(() => import("./views/pages/packages/Packages"));
const Chat = React.lazy(() => import("./views/pages/chat/Chat"));
const Profile = React.lazy(() => import("./views/pages/profile/Profile"));
const CoreUIIcons = React.lazy(() =>
  import("./views/icons/coreui-icons/CoreUIIcons")
);
const Flags = React.lazy(() => import("./views/icons/flags/Flags"));
const Brands = React.lazy(() => import("./views/icons/brands/Brands"));
const Alerts = React.lazy(() => import("./views/notifications/alerts/Alerts"));
const Badges = React.lazy(() => import("./views/notifications/badges/Badges"));
const Modals = React.lazy(() => import("./views/notifications/modals/Modals"));

const Widgets = React.lazy(() => import("./views/widgets/Widgets"));
const Users = React.lazy(() => import("./views/users/Users"));
const User = React.lazy(() => import("./views/users/User"));

const routes = [
  { path: "/", exact: true, name: "Scheduler" },
  { path: "/scheduler", name: "Scheduler", component: Scheduler },
  { path: "/tutors", name: "Tutors", component: Tutors },
  { path: "/students", name: "Students", component: Students },
  { path: "/lessons", name: "Lessons", component: Lessons },
  { path: "/payments", name: "Payments", component: Payments },
  { path: "/packages", name: "Packages", component: Packages },
  { path: "/chat", name: "Chat", component: Chat },
  { path: "/profile", name: "Profile", component: Profile },
  {
    path: "/buttons/button-dropdowns",
    name: "Dropdowns",
    component: ButtonDropdowns,
  },
  {
    path: "/buttons/button-groups",
    name: "Button Groups",
    component: ButtonGroups,
  },
  {
    path: "/buttons/brand-buttons",
    name: "Brand Buttons",
    component: BrandButtons,
  },
  { path: "/charts", name: "Charts", component: Charts },
  { path: "/icons", exact: true, name: "Icons", component: CoreUIIcons },
  { path: "/icons/coreui-icons", name: "CoreUI Icons", component: CoreUIIcons },
  { path: "/icons/flags", name: "Flags", component: Flags },
  { path: "/icons/brands", name: "Brands", component: Brands },
  {
    path: "/notifications",
    name: "Notifications",
    component: Alerts,
    exact: true,
  },
  { path: "/notifications/alerts", name: "Alerts", component: Alerts },
  { path: "/notifications/badges", name: "Badges", component: Badges },
  { path: "/notifications/modals", name: "Modals", component: Modals },
  { path: "/notifications/toaster", name: "Toaster", component: Toaster },
  { path: "/widgets", name: "Widgets", component: Widgets },
  { path: "/users", exact: true, name: "Users", component: Users },
  { path: "/users/:id", exact: true, name: "User Details", component: User },
];

export default routes;
