import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { CSidebar, CSidebarBrand } from "@coreui/react";

import Icon from "../assets/icons/download.png";
import IconMob from "../assets/icons/downloadMobile.png";
// sidebar nav config
import navigation from "./_nav";
import { Link, useLocation } from "react-router-dom";

const TheSidebar = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const show = useSelector((state) => state.sidebarShow);
  const [items, setItems] = useState(navigation);

  const onChange = (evt, item, i, action) => {
    let updatedItems = [...items];
    evt.preventDefault();
    if (i === 0) {
      if (action === "onMouseEnter") {
        updatedItems[i].path = item.hoverIcon;
      } else if (action === "onMouseOut") {
        updatedItems[i].path = item.icon;
      }
      setItems(updatedItems);
    }
    if (evt && item && i) {
      if (updatedItems && updatedItems.length > 0) {
        const findIndex = updatedItems.findIndex(
          (u) => u.name === evt.currentTarget.name
        );
        if (findIndex && findIndex !== -1) {
          if (action === "onMouseEnter") {
            updatedItems[findIndex].path = item.hoverIcon;
          } else if (action === "onMouseOut") {
            updatedItems[findIndex].path = item.icon;
          }
        }
        setItems(updatedItems);
      }
    }
  };

  return (
    <CSidebar
      show={show}
      onShowChange={(val) => dispatch({ type: "set", sidebarShow: val })}
    >
      <div className="displaynone_mobile">
        <CSidebarBrand className="d-md-down-none" to="/">
          <div className="logo-img">
            <img src={Icon} alt="" />
          </div>
        </CSidebarBrand>
        <div className="sidebar-left">
          <ul>
            {items.map((item, i) => (
              <li key={i}>
                <Link
                  name={item.name}
                  onMouseEnter={(e) => onChange(e, item, i, "onMouseEnter")}
                  onMouseOut={(e) => onChange(e, item, i, "onMouseOut")}
                  to={item.to}
                  className={item.to === location.pathname && "active"}
                >
                  <img
                    src={
                      item.to === location.pathname ? item.hoverIcon : item.path
                    }
                    alt=""
                    className="sidebar_img"
                  />{" "}
                  <span
                    style={{
                      color: item.to === location.pathname && "#3e7dff",
                    }}
                  >
                    {item.name}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div>
        <div className="sidebar_displynone ">
          <CSidebarBrand className="" to="/">
            <div className="logo-img1">
              <img src={IconMob} alt="" />
            </div>
          </CSidebarBrand>
          <ul>
            {items.map((item, i) => (
              <li key={i}>
                <Link
                  onMouseEnter={(e) => onChange(e, item, i, "onMouseEnter")}
                  onMouseOut={(e) => onChange(e, item, i, "onMouseOut")}
                  to={item.to}
                  className={item.to === location.pathname && "active"}
                >
                  <img
                    src={
                      item.to === location.pathname ? item.hoverIcon : item.path
                    }
                    alt=""
                    className="sidebar_img"
                  />
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </CSidebar>
  );
};

export default React.memo(TheSidebar);
