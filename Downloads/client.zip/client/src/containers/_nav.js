import SchedulerLogo from "../assets/icons/scheduler.png";
import SchedulerHoverLogo from "../assets/icons/scheduler-hover.png";
import TutorsLogo from "../assets/icons/tutors.png";
import TutorsHoverLogo from "../assets/icons/tutors-hover.png";
import StudentLogo from "../assets/icons/student.png";
import StudentHoverLogo from "../assets/icons/student-hover.png";
import LessonsLogo from "../assets/icons/lessons.png";
import LessonsHoverLogo from "../assets/icons/lessons-hover.png";
import PaymentLogo from "../assets/icons/payment.png";
import PaymentHoverLogo from "../assets/icons/payment-hover.png";
import PackagesLogo from "../assets/icons/packages.png";
import PackagesHoverLogo from "../assets/icons/packages-hover.png";
import ChatLogo from "../assets/icons/chat.png";
import ChatLogoHover from "../assets/icons/chat-hover.png";

const _nav = [
  {
    _tag: "CSidebarNavItem",
    name: "Scheduler",
    className: "Scheduler",
    to: "/scheduler",
    path: SchedulerLogo,
    icon:SchedulerLogo,
    hoverIcon: SchedulerHoverLogo,
  },
  {
    _tag: "CSidebarNavItem",
    name: "Tutors",
    className: "Tutors",
    to: "/tutors",
    path: TutorsLogo,
    icon: TutorsLogo,
    hoverIcon: TutorsHoverLogo,
  },
  {
    _tag: "CSidebarNavItem",
    name: "Students",
    className: "Students",
    to: "/students",
    path: StudentLogo,
    icon: StudentLogo,
    hoverIcon: StudentHoverLogo,
  },
  {
    _tag: "CSidebarNavItem",
    name: "Lessons",
    className: "Lessons",
    to: "/lessons",
    path: LessonsLogo,
    icon:LessonsLogo,
    hoverIcon: LessonsHoverLogo,
  },
  {
    _tag: "CSidebarNavItem",
    name: "Your Payments",
    className: "Payments",
    to: "/payments",
    path: PaymentLogo,
    icon: PaymentLogo,
    hoverIcon: PaymentHoverLogo,
  },
  {
    _tag: "CSidebarNavItem",
    name: "Packages",
    className: "Packages",
    to: "/packages",
    path: PackagesLogo,
    icon: PackagesLogo,
    hoverIcon: PackagesHoverLogo,
  },
  {
    _tag: "CSidebarNavItem",
    name: "Chat With Us",
    className: "Chat",
    to: "/chat",
    path: ChatLogo,
    icon: ChatLogo,
    hoverIcon: ChatLogoHover,
  },
];

export default _nav;
