import React from "react";
import {
  CDropdown,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
  CImg,
} from "@coreui/react";
import { useHistory } from "react-router-dom";
import ProfileImage from "../assets/icons/profile.png";
import LogoutImage from "../assets/icons/logout.png";

const TheHeaderDropdown = () => {
  const history = useHistory();

  const handleClick = () => {
    history.push("/profile");
  };

  return (
    <CDropdown inNav className="c-header-nav-items mx-2" direction="down">
      <CDropdownToggle className="c-header-nav-link" caret={false}>
        <div className="c-avatar">
          <CImg
            src={ProfileImage}
            className="c-avatar-img message_img"
            alt="admin@bootstrapmaster.com"
          />
        </div>
      </CDropdownToggle>
      <CDropdownMenu className="pt-0 header_profile" placement="bottom-end">
        <CDropdownItem onClick={handleClick}>
          <img src={ProfileImage} alt="" className="profile_img" />
          Profile
        </CDropdownItem>
        <CDropdownItem>
          <img src={LogoutImage} alt="" className="profile_img" />
          Sign out
        </CDropdownItem>
      </CDropdownMenu>
    </CDropdown>
  );
};

export default TheHeaderDropdown;
