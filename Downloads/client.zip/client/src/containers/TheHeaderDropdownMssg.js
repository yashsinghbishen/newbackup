import React from "react";
import {
  CBadge,
  CDropdown,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
} from "@coreui/react";
import MessageIcon from "../assets/icons/message.png";

const TheHeaderDropdownMssg = () => {
  const itemsCount = 4;
  return (
    <CDropdown inNav className="c-header-nav-item mx-2" direction="down">
      <CDropdownToggle className="c-header-nav-link" caret={false}>
        <img src={MessageIcon} alt="" className="message_img" />
        <CBadge shape="pill" color="warning">
          {itemsCount}
        </CBadge>
      </CDropdownToggle>
      <CDropdownMenu className="pt-0 message_list" placement="bottom-end">
        <CDropdownItem header tag="div" color="light" className="message_icon">
          <h3 className="headericon_heading">Messages</h3>
          <strong className="count_text">You have {itemsCount} messages</strong>
        </CDropdownItem>
        <CDropdownItem href="#">
          <div className="message">
            <div className="text-truncate font-weight-bold message_text">
              <span className="fa fa-exclamation text-danger"></span> Important
              message
            </div>
            <div className="small text-muted text-truncate smallmessage_text">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
              eiusmod tempor incididunt...<span>12:00am</span>
            </div>
          </div>
        </CDropdownItem>

        <CDropdownItem href="#">
          <div className="message">
            <div className="text-truncate font-weight-bold message_text">
              <span className="fa fa-exclamation text-danger"></span> Lorem
              ipsum dolor sit amet
            </div>
            <div className="small text-muted text-truncate smallmessage_text">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
              eiusmod tempor incididunt...<span>12:00am</span>
            </div>
          </div>
        </CDropdownItem>

        <CDropdownItem href="#">
          <div className="message">
            <div className="text-truncate font-weight-bold message_text">
              <span className="fa fa-exclamation text-danger"></span> Lorem
              ipsum dolor sit amet
            </div>
            <div className="small text-muted text-truncate smallmessage_text">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
              eiusmod tempor incididunt...<span>12:00am</span>
            </div>
          </div>
        </CDropdownItem>

        <CDropdownItem href="#">
          <div className="message">
            <div className="text-truncate font-weight-bold message_text">
              <span className="fa fa-exclamation text-danger"></span> Lorem
              ipsum dolor sit amet
            </div>
            <div className="small text-muted text-truncate smallmessage_text">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
              eiusmod tempor incididunt...<span>12:00am</span>
            </div>
          </div>
        </CDropdownItem>
      </CDropdownMenu>
    </CDropdown>
  );
};

export default TheHeaderDropdownMssg;
