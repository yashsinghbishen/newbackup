import React from "react";

const TheFooter = () => {
  return <div></div>;
};

export default React.memo(TheFooter);
