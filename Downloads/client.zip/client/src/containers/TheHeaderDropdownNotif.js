import React from "react";
import {
  CBadge,
  CDropdown,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
} from "@coreui/react";
import BellIcon from "../assets/icons/bell.png";

const TheHeaderDropdownNotif = () => {
  const itemsCount = 5;
  return (
    <CDropdown inNav className="c-header-nav-item mx-2">
      <CDropdownToggle className="c-header-nav-link" caret={false}>
        <img src={BellIcon} alt="" className="notification_img" />
        <CBadge shape="pill" color="warning">
          {itemsCount}
        </CBadge>
      </CDropdownToggle>
      <CDropdownMenu
        placement="bottom-end"
        className="pt-0 dropdown-menunotification"
      >
        <CDropdownItem
          header
          tag="div"
          className="dropdown-headerbg notification_navbar"
          color="light"
        >
          <h3 className="headericon_heading ">Notification</h3>
          <strong className="noticount_text">
            You have {itemsCount} notifications
          </strong>
        </CDropdownItem>
        <CDropdownItem href="#">
          <div className="message notification_list">
            <div className="text-truncate font-weight-bold message_text">
              <span className="fa fa-exclamation text-danger"></span> Important
              message
            </div>
            <div className="small text-muted text-truncate smallmessage_text">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
              eiusmod tempor incididunt...<span>12:00am</span>
            </div>
          </div>
        </CDropdownItem>

        <CDropdownItem href="#">
          <div className="message notification_list">
            <div className="text-truncate font-weight-bold message_text">
              <span className="fa fa-exclamation text-danger"></span> Lorem
              ipsum dolor sit amet
            </div>
            <div className="small text-muted text-truncate smallmessage_text">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
              eiusmod tempor incididunt...<span>12:00am</span>
            </div>
          </div>
        </CDropdownItem>

        <CDropdownItem href="#">
          <div className="message notification_list">
            <div className="text-truncate font-weight-bold message_text">
              <span className="fa fa-exclamation text-danger"></span> Lorem
              ipsum dolor sit amet
            </div>
            <div className="small text-muted text-truncate smallmessage_text">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
              eiusmod tempor incididunt...<span>12:00am</span>
            </div>
          </div>
        </CDropdownItem>

        <CDropdownItem href="#">
          <div className="message">
            <div className="text-truncate font-weight-bold message_text">
              <span className="fa fa-exclamation text-danger"></span> Lorem
              ipsum dolor sit amet
            </div>
            <div className="small text-muted text-truncate smallmessage_text">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
              eiusmod tempor incididunt...<span>12:00am</span>
            </div>
          </div>
        </CDropdownItem>
      </CDropdownMenu>
    </CDropdown>
  );
};

export default TheHeaderDropdownNotif;
