import React from "react";
import { useHistory } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { CHeader, CHeaderBrand, CHeaderNav } from "@coreui/react";
import ToggleLogo from "../assets/icons/toggle.png";
import CIcon from "@coreui/icons-react";
import {
  TheHeaderDropdown,
  TheHeaderDropdownMssg,
  TheHeaderDropdownNotif,
} from "./index";

const TheHeader = (props) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const sidebarShow = useSelector((state) => state.sidebarShow);

  const toggleSidebar = () => {
    const val = [true, "responsive"].includes(sidebarShow)
      ? false
      : "responsive";
    dispatch({ type: "set", sidebarShow: val });
  };

  const toggleSidebarMobile = () => {
    const val = [false, "responsive"].includes(sidebarShow)
      ? true
      : "responsive";
    dispatch({ type: "set", sidebarShow: val });
  };

  const renderHeaderTitleName = () => {
    if (history.location.pathname === "/scheduler") {
      return <div>Scheduler</div>;
    } else if (history.location.pathname === "/tutors") {
      return <div>Tutors</div>;
    } else if (history.location.pathname === "/students") {
      return <div>Students</div>;
    } else if (history.location.pathname === "/lessons") {
      return <div>Lessons</div>;
    } else if (history.location.pathname === "/payments") {
      return <div>Your Payments</div>;
    } else if (history.location.pathname === "/packages") {
      return <div>Packages</div>;
    } else if (history.location.pathname === "/chat") {
      return <div>Chat With Us</div>;
    } else if (history.location.pathname === "/profile") {
      return <div>Profile</div>;
    }
  };

  return (
    <CHeader withSubheader className="header_container">
      <img
        src={ToggleLogo}
        alt="togglemob"
        inHeader
        className="ml-md-3 d-lg-none menu_img mobmenu"
        onClick={toggleSidebarMobile}
      />
      <img
        src={ToggleLogo}
        alt="toggle"
        inHeader
        className="ml-3 d-md-down-none menu_img"
        onClick={toggleSidebar}
      />

      <CHeaderBrand className="mx-auto d-lg-none" to="/">
        <CIcon name="logo" height="48" alt="Logo" />
      </CHeaderBrand>

      <CHeaderNav className=" mr-auto header_navheadtext">
        {renderHeaderTitleName()}
      </CHeaderNav>

      <CHeaderNav className="px-3 top_navnotification">
        <TheHeaderDropdownNotif />
        <TheHeaderDropdownMssg />
        <TheHeaderDropdown />
      </CHeaderNav>
    </CHeader>
  );
};

export default TheHeader;
