from django.conf import settings

# ------------------------------------------------------------ #


# ----------------------------------------- #
# Settings Variables:
# ----------------------------------------- #
def settings_variables(request):
    """
    Applies the environment's necessary settings variables into the template context.
    """
    return {}
