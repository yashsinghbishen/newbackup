from django.db import models


class Breed(models.Model):
    breed = models.CharField(max_length=128, null=False, blank=False)


class BreedImage(models.Model):
    breed = models.ForeignKey(
        Breed, on_delete=models.CASCADE, related_name="breed_images")
    image = models.ImageField(upload_to='images')
