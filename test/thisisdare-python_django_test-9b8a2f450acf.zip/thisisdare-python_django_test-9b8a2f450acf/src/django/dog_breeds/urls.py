from django.urls import path

from . import views

urlpatterns = [

    path('list/', views.BreedList.as_view(), name='breeds_list'),
    path('<str:breed>/images/<int:count>/', views.BreedImageList.as_view(), name='breed_image'),
]
