from urllib.request import urlopen

import requests
from dog_breeds.models import Breed, BreedImage
from django.core.files import File
from django.core.files.temp import NamedTemporaryFile
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = 'Store Dog API images and breed'

    def handle(self, *args, **kwargs):
        '''
        Management Command to fetch api and get all images. Store that images into django database.
        '''
        # Get dog breed list from api.
        res = requests.get("https://dog.ceo/api/breeds/list/all")
        data = res.json()
        breed_list = list(data["message"].keys())

        for breed in breed_list:
            # Get breed from local database or save breed if not found.
            breed, _ = Breed.objects.get_or_create(breed=breed)

            # Get dog breed images list from api by breed name.
            res = requests.get("https://dog.ceo/api/breed/" +
                               breed.breed + "/images/")
            img_list = res.json()["message"]

            for img in img_list[:20]:
                image_url = img
                img_temp = NamedTemporaryFile(delete=True)
                img_temp.write(urlopen(image_url).read())
                img_temp.flush()
                # save breed image
                breed_image = BreedImage(breed=breed)
                breed_image.image.save(
                    image_url.rsplit('/')[1], File(img_temp))
                breed_image.save()
