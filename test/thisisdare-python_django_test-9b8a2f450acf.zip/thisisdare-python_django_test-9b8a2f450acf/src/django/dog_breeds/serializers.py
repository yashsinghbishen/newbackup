from rest_framework import serializers

from .models import BreedImage, Breed


class BreedImageSerializer(serializers.ModelSerializer):
    breed = serializers.SerializerMethodField()
    

    class Meta:
        model = BreedImage
        fields = ('breed', 'image')
    
    def get_breed(self, obj):
        return obj.breed.breed


class BreedSerializer(serializers.ModelSerializer):

    image_count = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Breed
        fields = ('id', 'breed', 'image_count')

    def get_image_count(self, obj):
        return obj.breed_images.all().count()
