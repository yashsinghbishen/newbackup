from rest_framework.generics import ListAPIView

from .models import Breed, BreedImage
from .serializers import BreedSerializer, BreedImageSerializer


class BreedList(ListAPIView):
    """
        Api to get list of dog breeds and number of images saved in local database.
    """

    queryset = Breed.objects.all()
    serializer_class = BreedSerializer


class BreedImageList(ListAPIView):
    """
        Api to get list of dog breeds images saved in local database by breed name and limit.
    """

    serializer_class = BreedImageSerializer

    def get_queryset(self):
        breed = self.kwargs['breed']
        count = self.kwargs['count']

        return BreedImage.objects.filter(breed__breed=breed)[:count]
