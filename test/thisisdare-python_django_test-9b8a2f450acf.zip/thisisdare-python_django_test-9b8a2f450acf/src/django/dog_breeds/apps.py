from django.apps import AppConfig


class DogBreedConfig(AppConfig):
    name = 'dog_breed'
