from django.contrib import admin

from .models import Breed, BreedImage

admin.site.register(Breed)
admin.site.register(BreedImage)
