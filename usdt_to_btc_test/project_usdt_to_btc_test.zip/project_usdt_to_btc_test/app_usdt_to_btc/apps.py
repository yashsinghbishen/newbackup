from django.apps import AppConfig


class AppUsdtToBtcConfig(AppConfig):
    name = 'app_usdt_to_btc'
