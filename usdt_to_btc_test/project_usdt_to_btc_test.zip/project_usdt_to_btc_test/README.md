# Test task for BTC/USDT conversion.

## Route
    /spendings
## Request Params
    side: "BUY" or "SELL"
    amount: Number of BTC 
## Response
    {
        "side": "SELL",
        "amount": 3134.999993563456,
        "usdt_required": 185224765.7197106
    }